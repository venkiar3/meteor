require("./import_globals.js");
require("es5-shim/es5-shim.js");
require("./export_globals.js");
