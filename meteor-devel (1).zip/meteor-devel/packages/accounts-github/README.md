# accounts-github

A login service for GitHub. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.