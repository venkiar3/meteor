Package.describe({
  summary: "Disables oplog tailing",
  version: '1.0.7'
});

// This package is empty; its presence is detected by mongo-livedata.
