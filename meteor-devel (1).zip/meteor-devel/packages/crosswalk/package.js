Package.describe({
  summary: "Makes your Cordova application use the Crosswalk WebView \
instead of the System WebView on Android",
  version: '1.6.2',
  documentation: null
});

Cordova.depends({
  'cordova-plugin-crosswalk-webview': '1.6.0'
});
