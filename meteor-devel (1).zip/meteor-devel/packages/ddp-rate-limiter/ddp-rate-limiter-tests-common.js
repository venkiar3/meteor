// Common settings for DDPRateLimiter tests.
RATE_LIMIT_NUM_CALLS = 5;
RATE_LIMIT_INTERVAL_TIME_MS = 5000;