# accounts-meteor-developer

A login service for Meteor developer accounts. See the project page on
[Meteor Accounts](https://www.meteor.com/accounts) and Meteor [Developer
Accounts](https://www.meteor.com/services/developer-accounts) for more
details.