export const testingForImportedModule987654321 = true;
