# blaze-html-templates

A meta-package that includes everything you need to compile and run Meteor templates with Spacebars and Blaze.

For more details, see the documentation of the component packages:

- [templating](https://atmospherejs.com/meteor/templating): compiles `.html` files
- [blaze](https://atmospherejs.com/meteor/blaze): the runtime library
- [spacebars](https://atmospherejs.com/meteor/spacebars): the templating language
