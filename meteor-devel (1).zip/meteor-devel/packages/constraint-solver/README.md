# constraint-solver

Meteor Version Solver is an optimizing constraint solver for package
dependencies. It is used by the Meteor build tool (Isobuild) for apps,
packages and build plugins.

To learn more about Meteor Version Solver see the [project page on
meteor.com](https://www.meteor.com/version-solver)

