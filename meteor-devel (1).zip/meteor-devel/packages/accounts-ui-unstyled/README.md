# accounts-ui-unstyled

A version of `accounts-ui` without the CSS, so that you can add your
own styling. See the [`accounts-ui`
README](https://atmospherejs.com/meteor/accounts-ui) and the
Meteor Accounts [project page](https://www.meteor.com/accounts) for
details.