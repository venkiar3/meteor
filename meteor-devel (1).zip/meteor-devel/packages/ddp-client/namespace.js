/**
 * @namespace DDP
 * @summary Namespace for DDP-related methods/classes.
 */
DDP          = {};
LivedataTest = {};
