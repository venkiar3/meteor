// TODO Allow just api.mainModule("meteor-ecmascript-runtime");
module.exports = require("meteor-ecmascript-runtime");
