# email

The `email` package allows sending email from a Meteor app.

To see how to use it, read the [`email` section](http://docs.meteor.com/#email) of the Meteor docs.