# accounts-google

A login service for Google. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.