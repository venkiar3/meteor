# browser-policy-framing

This is one of a family of packages that can be used to easily
configure an app's browser-side security policies. The documentation
is in the
[browser-policy](https://atmospherejs.com/meteor/browser-policy)
package.
