# hot-code-push

Enables Meteor's hot code push functionality in development and production by
including the `autoupdate` and `reload` packages in your app.
