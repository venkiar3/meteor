# accounts-weibo

A login service for Weibo. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.