Circles = new Mongo.Collection("circles");
